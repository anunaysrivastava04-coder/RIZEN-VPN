(() => {
  const CSS = [
    ".adsbygoogle","[data-ad]","[data-ad-slot]","[data-adunit]","[aria-label*='advert' i]",
    "[class~='advertisement']","[id~='advertisement']","[class*='ad-container']","[id^='google_ads']",
    ".ad-banner",".ad-wrapper",".sponsored-content",".sponsor-block",".sponsored-post",
    "ytd-display-ad-renderer","ytd-promoted-sparkles-text-search-renderer","ytd-in-feed-ad-layout-renderer"
  ].join(",");
  let style;
  const apply=async()=>{
    const {adBlockEnabled=false}=await chrome.storage.local.get("adBlockEnabled");
    if(adBlockEnabled){
      if(!style){style=document.createElement("style");style.textContent=CSS+"{display:none!important;visibility:hidden!important;max-height:0!important;overflow:hidden!important}";(document.documentElement||document.head).appendChild(style);}
    }else if(style){style.remove();style=null;}
  };
  apply();
  chrome.storage.onChanged.addListener((changes,area)=>{if(area==="local"&&changes.adBlockEnabled)apply();});
  const observer=new MutationObserver(()=>{ if(style) document.querySelectorAll(CSS).forEach(el=>{el.style.setProperty("display","none","important");el.style.setProperty("visibility","hidden","important");}); });
  observer.observe(document.documentElement,{childList:true,subtree:true});
})();
